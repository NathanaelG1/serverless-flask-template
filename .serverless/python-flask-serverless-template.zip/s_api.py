import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='nathanaelguirguis',
    application_name='flask-serverless-template',
    app_uid='hq8hk3L5bnXpyrlrf8',
    org_uid='5f1d1de4-d278-4cd5-9741-e4706595c91c',
    deployment_uid='a54d4e77-fad4-4f92-a6dd-2e8aa84490aa',
    service_name='python-flask-serverless-template',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='6.2.3',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'python-flask-serverless-template-dev-api', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
